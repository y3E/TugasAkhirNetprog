Run Xampp > Start Apache
Execute startserve.bat
buka di browser localhost/[folder_chat]

Hosting : http://ajierifky.000webhostapp.com/espe/